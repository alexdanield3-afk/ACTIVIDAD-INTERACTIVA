# 🌌 MULTIVERSE CHALLENGE

Juego de aventura **en equipos y en tiempo real** para una clase de 15–30 personas (soporta hasta 40).
El organizador crea la partida, los estudiantes entran desde el celular con un código, el sistema arma equipos
balanceados (4–5 integrantes) con nombre, color y escudo, y juegan retos de 60 segundos con chat privado por equipo,
ruleta, poderes, mapa de aventura, marcador animado y ceremonia final.

## Cómo usarlo en clase (5 minutos)

1. Instala Node.js 20 o superior (https://nodejs.org).
2. En esta carpeta ejecuta:
   ```bash
   npm install
   npm start
   ```
3. El programa imprime las direcciones. El organizador abre **http://localhost:3000/host** en su computador.
4. Los estudiantes se conectan a la misma red Wi‑Fi y abren la dirección «Estudiantes» que aparece en la consola
   (por ejemplo `http://192.168.1.20:3000`) o **escanean el código QR** de la sala de espera. Escriben su nombre y el código de 5 letras.
5. Proyecta la pantalla del organizador (botón **📺 Pantalla grande**, o **🪟 Abrir proyector** en una segunda ventana) y pulsa **⚔️ INICIAR AVENTURA**.

> Si la red de la universidad aísla los dispositivos entre sí, usa el hotspot del celular del organizador
> o publica el servidor en internet (ver «Publicarlo en línea»).

## Probar todo sin estudiantes: MODO DEMO

En la pantalla de creación elige un universo, pulsa **10 / 15 / 20 / 25 / 30** en el recuadro **Modo demo** y
**▶ Crear partida DEMO**. Los bots charlan en sus chats de equipo, responden, giran la ruleta, usan poderes, roban puntos
y cambian de posición en el ranking. Puedes entrar tú también como jugador (otro navegador, con el código) para ver la experiencia real.
«Ritmo rápido» acorta el marcador y la revelación (5–6 s) para ver una partida completa en pocos minutos.

## Lo que incluye

- **16 universos** con preguntas, equipos, escudos y mensajes propios (≈465 ítems): Vikingos, Edad Media, Marvel/Vengadores,
  Harry Potter, Ciencia ficción, Dinosaurios, Mitología, Fútbol, Videojuegos, Tecnología, Inteligencia Artificial, **Claude AI**
  (situaciones prácticas), Historia, Ciencia, Geografía y Educación.
- **MODO CAOS**: cada reto sale de un universo distinto.
- **CREAR TEMA**: escribe cualquier tema. Tres vías: (1) *IA de Claude* si configuras `ANTHROPIC_API_KEY`; (2) *Pegar JSON*:
  copias unas instrucciones, las pegas en cualquier IA y pegas el resultado; (3) *Rápido*: preguntas de cultura general con tu tema como nombre.
- **12 tipos de reto**: Quiz, Verdadero/Falso, Ruleta, ¿Qué harías?, Ordena, Memoria, Adivina, Conexión, Reto rápido,
  Elección estratégica, Bonus y Jefe final (más una Semifinal).
- **Chat privado por equipo** (aislado en el servidor). El organizador no escribe, pero puede **observar** todos los chats si activa la opción.
- **Respuesta de equipo**: cualquiera elige (el borrador es compartido) y cualquiera bloquea; si se acaba el tiempo se envía lo elegido.
- **Temporizador de 60 s** sincronizado con el servidor, «TIEMPO AGOTADO» y pausa/reanudar del organizador.
- **Ruleta animada** (12 casillas: +100, +200, DOBLE, pregunta fácil/difícil, BONUS, ROBA 50, ESCUDO, PISTA, RETO SORPRESA, −50, «EL ORGANIZADOR DECIDE»).
- **Poderes**: Escudo (automático), Doble, Pista, Tiempo extra +15 s y Robo.
- **Puntuación**: +100 acierto, +200 difícil, +500 jefe, bonus +50, rapidez (máx. 25, nunca pesa más que acertar).
- **Marcador animado**, **mapa de aventura**, insignias y **ceremonia «CAMPEONES DEL MULTIVERSE CHALLENGE»** con podio.
- **Panel del organizador**: crear, tema, equipos (renombrar, regenerar escudo, redistribuir, expulsar), iniciar, pausar, reanudar,
  terminar ronda, cambiar o elegir el siguiente reto, ver respuestas (opcional), controlar la ruleta, bonus, poderes, ajustar puntos, finalizar y reiniciar.
- Reconexión automática: si un estudiante o el organizador recarga la página, vuelve a su equipo o partida.

## Cómo está construido

| Parte | Detalle |
|---|---|
| Servidor | Node.js + `ws`; estado en memoria; el servidor decide tiempo, puntos y respuestas correctas. |
| Seguridad del juego | A cada jugador sólo se le envía su propia vista: **la respuesta correcta no sale del servidor hasta la revelación**; los chats se envían sólo a su equipo. |
| Cliente | HTML/CSS/JS puro, sin librerías ni CDN (funciona sin internet), pensado primero para móvil. |
| Carga | Probado con 30 conexiones simultáneas (ver pruebas). |

```
server/   index.js (HTTP + WebSocket) · game.js (motor) · bots.js (demo) · ai.js (temas) · content/ (16 universos)
public/   index.html (jugador) · host.html (organizador) · css/ · js/
test/     sim.js · content-check.js · e2e.js · ui.py
```

## Variables de entorno (opcionales)

| Variable | Para qué |
|---|---|
| `PORT` | Puerto (por defecto 3000). |
| `PUBLIC_URL` | Dirección pública que se muestra en el QR (si lo publicas en internet). |
| `ANTHROPIC_API_KEY` | Activa la generación de temas con Claude. `CLAUDE_MODEL` cambia el modelo. |

## Publicarlo en línea

Sirve cualquier servicio que ejecute Node.js y admita WebSockets (Render, Railway, Fly.io, un VPS…). Comando de inicio: `npm start`.
Define `PUBLIC_URL` con tu dominio `https://…`. Mantén **una sola instancia** (el estado vive en memoria).

## Pruebas

```bash
npm test                      # valida el contenido y simula una partida completa
npm start   (y en otra terminal)   npm run e2e    # 30 clientes WebSocket reales: equipos, chat aislado, pausa, poderes, reconexión, partida completa
python3 test/ui.py            # (opcional, requiere Playwright) recorrido de la interfaz con capturas
```

## Límites conocidos

- Si el servidor se reinicia, las partidas en curso se pierden (no hay base de datos).
- La generación de temas con IA depende de tu clave y del formato que devuelva el modelo; si falla, usa «Pegar JSON» o «Rápido».
- Los escudos son emblemas heráldicos genéricos (sin logotipos ni personajes de marcas); los universos de películas o series usan sólo texto y emojis.
